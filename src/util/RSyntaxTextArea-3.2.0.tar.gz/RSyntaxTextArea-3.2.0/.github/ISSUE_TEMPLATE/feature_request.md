---
name: Feature request
about: Suggest an enhancement for this library
title: ''
labels: enhancement
assignees: ''

---

**Describe the solution you'd like**
A clear and concise description of what you want to happen.

**Are there any workarounds?**
Are there any workarounds for folks while this feature is not yet implemented?

**Additional context**
Add any other context or screenshots about the feature request here.
